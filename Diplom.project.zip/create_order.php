<?php

session_start();

require_once 'vendor/connect.php';

$user_id = $_SESSION['user']['id'];

$service_name = $_POST['service_name'];

$comment = $_POST['comment'];

$service_name = mysqli_real_escape_string(
    $connect,
    $service_name
);

$comment = mysqli_real_escape_string(
    $connect,
    $comment
);

mysqli_query(
    $connect,

    "INSERT INTO orders
    (user_id, service_name, comment)

    VALUES

    ('$user_id', '$service_name', '$comment')"
);

header('Location: index.php');